<template>
  <header>
    <Navbar />
  </header>
  <h1>about</h1>
</template>

<script setup>
import Navbar from '../components/Navbar.vue';
</script>

<style scoped>

</style>