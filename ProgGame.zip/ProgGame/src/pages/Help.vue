<template>
  <Navbar />
  <h1>help</h1>
</template>

<script setup>
import Navbar from '../components/Navbar.vue';
</script>

<style scoped>

</style>