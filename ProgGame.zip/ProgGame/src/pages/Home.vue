<script setup>
  import Navbar from '../components/Navbar.vue';
</script>

<template>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Secular+One&display=swap" rel="stylesheet">

  <main>
    <header>
      <Navbar />
    </header>
    <div class="container">
      <div>
        <img src="images/homepic2.svg" alt="" class="image1">
      </div>
      <div class="content">
        <h1>Competitive Programming</h1>
        <p>Improve your programming skills through fun game modes and watch your abilities grow</p>
        <router-link to="/signup" >Sign up</router-link>
      </div>
    </div>
  </main>
  <div class="main2"></div>
</template>

<style scoped>
main {
  width: 100vw;
  height: 100vh;
  background-image: radial-gradient(#800080, #330433);
  /*background-image: radial-gradient(#800080, #700070);*/
}

* {
  font-family: 'Secular One', sans-serif;
}

.container {
  display: grid;
  grid-template-columns: 1fr 1fr;
  align-items: center;
  width: 80%;
  margin: 0 auto;
  height: 90vh;
}

.image1 {
  width: 85vh;
}

.content {
  margin-left: 10px;
  color: white;
}

h1 {
  font-size: 40px;
}

p {
  font-size: 25px;
}

a {
  color: black;
  background-color: white;
  font-size: 25px;
  padding: 7px 20px;
  border-radius: 5px;
  text-decoration: none;
}
</style>
