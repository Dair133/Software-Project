<template>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Secular+One&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.3/font/bootstrap-icons.css">

  <main>
    <header>
      <Navbar />
    </header>
    <div class="container">
      <div class="signup-box">
        <img src="images/undraw_smiley-face.svg" alt="" class="image1">
        <h1>Sign up</h1>
        <form>
          <div class="inputs">
            <div class="input-area">
              <i class="bi bi-envelope"></i>
              <input type="email" class="input" placeholder="Email">
            </div>
            <div class="input-area">
              <i class="bi bi-person"></i>
              <input type="text" class="input" placeholder="Username">
            </div>
            <div class="input-area">
              <i class="bi bi-lock"></i>
              <input type="password" class="input" placeholder="Password">
            </div>
            <div class="input-area">
              <i class="bi bi-lock"></i>
              <input type="password" class="input" placeholder=" Confirm Password">
            </div>
            <div class="button">
<!--              <button class="btn" type="submit">Sign up</button>-->
              <router-link class="btn" to="/play">Sign up</router-link>
            </div>
          </div>
        </form>
        <div class="login">
          <p>Have an account? <router-link to="/login">Login</router-link></p>
        </div>
      </div>
    </div>
  </main>
</template>

<script setup>
import Navbar from '../components/Navbar.vue';
</script>

<style scoped>

* {
  padding: 0;
  margin: 0;
  box-sizing: border-box;
  font-family: 'Secular One', sans-serif;
}

.container {
  width: 100vw;
  height: 90vh;
  background-image: radial-gradient(#800080, #330433);
}

.signup-box {
  background-color: white;
  width: 400px;
  margin: 0 auto;
  top: 13%;
  text-align: center;
  border-radius: 15px;
  border-style: solid;
  border-color: black;
}

h1 {
  font-size: 40px;
  margin-bottom: 30px;
}

.input {
  width: 50%;
  margin: 10px 0;
  border-radius: 10px;
  padding: 10px;
}

.btn {
  color: black;
  background-color: white;
  border-radius: 5px;
  border-style: solid;
  padding: 9px 20px;
  margin-top: 5px;
  width: 40%;
  cursor: pointer;
  text-decoration: none;
}


.login {
  margin-top: 30px;
  margin-bottom: 10px;
}

a {
  color: black;
}

.image1 {
  margin-top: 10px;
}

.button {
  margin-top: 20px;
}

</style>