function loadPage (component) {
// '@' is aliased to src/components
    return () => import(/* webpackChunkName: "[request]" */
        `@/pages/${component}.vue`)}
export default [
    { path: '/', component: loadPage('Home') },
    { path: '/login', component: loadPage('Login') },
    { path: '/help', component: loadPage('Help') },
    { path: '/aboutus', component: loadPage('Aboutus') },
    { path: '/signup', component: loadPage('Signup') },
    { path: '/play', component: loadPage('Play') }
]